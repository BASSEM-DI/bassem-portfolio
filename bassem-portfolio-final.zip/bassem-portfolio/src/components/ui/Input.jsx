export default function Input({ label, name, type = 'text', value, onChange, onBlur, error = '', placeholder, disabled = false }) {
  return (
    <div>
      <label htmlFor={name} className="mb-2 block text-sm font-medium text-slate-200">{label}</label>
      <input id={name} name={name} type={type} value={value} onChange={onChange} onBlur={onBlur} placeholder={placeholder} disabled={disabled} required aria-invalid={Boolean(error)} aria-describedby={error ? `${name}-error` : undefined} className={`w-full rounded-lg border bg-slate-950/50 px-4 py-3 text-slate-200 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-400 disabled:opacity-60 ${error ? 'border-red-400' : 'border-slate-700'}`} />
      {error && <p id={`${name}-error`} className="mt-2 text-sm text-red-400">{error}</p>}
    </div>
  )
}
