import { ArrowUpRight, Code2, FileCode2 as Github } from 'lucide-react'
const gradients = ['from-indigo-600/40 to-purple-500/10', 'from-cyan-600/40 to-blue-500/10', 'from-purple-600/40 to-pink-500/10']
function ProjectLink({ href, children }) {
  if (!href || href === '#') return <span aria-disabled="true" title="Link coming soon" className="inline-flex items-center gap-2 text-sm text-slate-500">{children}<span className="sr-only"> (coming soon)</span></span>
  return <a href={href} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-sm text-slate-300 transition-colors hover:text-indigo-300">{children}</a>
}
export default function ProjectCard({ project }) {
  return (
    <article className="flex h-full min-w-0 flex-col overflow-hidden rounded-xl border border-slate-800 bg-slate-900 transition-all hover:-translate-y-1 hover:border-slate-600">
      <div aria-hidden="true" className={`flex h-40 items-center justify-between bg-gradient-to-br ${gradients[(project.id - 1) % gradients.length]} p-8`}><Code2 size={48} className="text-white/70" /><span className="text-5xl font-bold text-white/10">{String(project.id).padStart(2, '0')}</span></div>
      <div className="flex flex-1 flex-col p-6"><h3 className="text-xl font-semibold text-white">{project.title}</h3><p className="mt-3 text-sm leading-7 text-slate-400">{project.description}</p><div className="my-5 flex flex-wrap gap-2">{project.tech.map((tech) => <span key={tech} className="rounded-full bg-indigo-500/10 px-3 py-1 text-xs text-indigo-300">{tech}</span>)}</div><div className="mt-auto flex flex-wrap gap-5 border-t border-slate-800 pt-5"><ProjectLink href={project.link}>Live Demo <ArrowUpRight size={16} /></ProjectLink><ProjectLink href={project.repo}>Code <Github size={16} /></ProjectLink></div></div>
    </article>
  )
}
