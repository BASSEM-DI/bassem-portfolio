export default function SkillBadge({ skill }) {
  return <span className="inline-flex items-center rounded-full border border-slate-700 bg-slate-800/50 px-4 py-2 text-sm text-slate-300 transition-all hover:border-indigo-400 hover:text-indigo-300">{skill}</span>
}
