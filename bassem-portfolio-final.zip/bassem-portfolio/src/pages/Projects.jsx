import { projects } from '../data/projects'
import ProjectCard from '../components/portfolio/ProjectCard'
import SectionTitle from '../components/ui/SectionTitle'
export default function Projects() {
  return <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8"><SectionTitle title="Projects" subtitle="A selection of things I've built" /><p className="mb-8 text-sm text-slate-400">Demo and code links will be added as projects become available.</p>{projects.length ? <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">{projects.map((project) => <ProjectCard key={project.id} project={project} />)}</div> : <p className="rounded-xl border border-slate-800 p-8 text-slate-400">New projects are on the way. Check back soon.</p>}</section>
}
