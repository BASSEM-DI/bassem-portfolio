import { Mail, ContactRound as Linkedin, ArrowUpRight } from 'lucide-react'
import SectionTitle from '../components/ui/SectionTitle'
import Input from '../components/ui/Input'
import Textarea from '../components/ui/Textarea'
import Button from '../components/ui/Button'
import useContactForm from '../hooks/useContactForm'
import { validateContactForm } from '../utils/validators'
export default function Contact() {
  const { values, errors, touched, isSubmitting, isSuccess, handleChange, handleBlur, handleSubmit } = useContactForm()
  const invalid = Object.values(validateContactForm(values)).some(Boolean)
  const fieldProps = (name) => ({ name, value: values[name], onChange: handleChange, onBlur: handleBlur, error: touched[name] ? errors[name] : '', disabled: isSubmitting || isSuccess })
  return (
    <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8"><SectionTitle title="Contact" subtitle="Let's get in touch" />
      <div className="grid items-start gap-8 md:grid-cols-[1fr_1.5fr]">
        <aside className="min-w-0 rounded-xl border border-slate-800 bg-slate-900 p-6 sm:p-8"><h2 className="text-xl font-semibold text-white">Start a conversation</h2><p className="mb-8 mt-3 leading-7 text-slate-400">For ideas, opportunities, or a simple hello, reach out directly using the links below.</p><div className="space-y-7"><div><p className="mb-2 flex items-center gap-2 text-sm text-slate-400"><Mail size={18} /> Email</p><a className="break-all text-indigo-300 hover:text-indigo-200" href="mailto:Bassemdjeddi78@gmail.com">Bassemdjeddi78@gmail.com</a></div><div><p className="mb-2 flex items-center gap-2 text-sm text-slate-400"><Linkedin size={18} /> LinkedIn</p><a href="https://www.linkedin.com/in/bassem-djeddi-835682360/" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-indigo-300 hover:text-indigo-200">Bassem Djeddi <ArrowUpRight size={16} /></a></div></div></aside>
        <form noValidate onSubmit={handleSubmit} className="min-w-0 space-y-5 rounded-xl border border-slate-800 bg-slate-900 p-6 sm:p-8"><h2 className="text-xl font-semibold text-white">Send a message</h2><p className="text-sm text-slate-400">Course demo: this form simulates submission and does not deliver email. All fields are required.</p><Input label="Name" placeholder="Your name" {...fieldProps('name')} /><Input label="Email" type="email" placeholder="you@example.com" {...fieldProps('email')} /><Input label="Subject" placeholder="What would you like to discuss?" {...fieldProps('subject')} /><Textarea label="Message" placeholder="Tell me about your idea…" {...fieldProps('message')} /><Button type="submit" disabled={invalid || isSubmitting || isSuccess} className="w-full sm:w-auto">{isSubmitting ? 'Sending...' : isSuccess ? '✓ Sent!' : 'Send Message'}</Button><div role="status" aria-live="polite">{isSuccess && <p className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-4 text-sm text-emerald-300">Demo submission successful! No email was sent. To reach me, use the email link. The form will reset shortly.</p>}</div></form>
      </div>
    </section>
  )
}
