import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
      <h1 className="text-6xl font-bold text-primary mb-4">404</h1>
      <p className="text-slate-300 mb-8">Page not found</p>
      <Link
        to="/"
        className="inline-block px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary/80 transition"
      >
        Back to Home
      </Link>
    </section>
  )
}