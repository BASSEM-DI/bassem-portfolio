import { Link } from 'react-router-dom'
import { ArrowRight, Code2 } from 'lucide-react'
import SectionTitle from '../components/ui/SectionTitle'
import SkillBadge from '../components/portfolio/SkillBadge'
const skills = ['React', 'JavaScript', 'HTML', 'CSS', 'Tailwind CSS', 'Git', 'GitHub', 'Vite', 'REST APIs', 'Responsive Design', 'UI/UX Basics', 'Problem Solving']
const linkStyle = 'inline-flex items-center justify-center gap-2 rounded-lg px-6 py-3 font-medium transition-all hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400'
export default function Home() {
  return (
    <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
      <section className="grid items-center gap-12 py-20 lg:grid-cols-[1.4fr_1fr] lg:py-28">
        <div><p className="mb-4 text-lg text-indigo-300">Hi, I'm</p><h1 className="text-5xl font-bold leading-tight tracking-tight text-white sm:text-6xl lg:text-7xl">Bassem Djeddi<span className="text-indigo-400">.</span></h1><p className="mt-5 text-2xl text-slate-300">Developer</p><p className="mt-6 max-w-xl leading-8 text-slate-400">I'm Bassem Djeddi, a passionate developer focused on building clean, modern web interfaces. I enjoy turning ideas into functional, user-friendly applications and I'm constantly learning new technologies to sharpen my craft.</p><div className="mt-8 flex flex-wrap gap-4"><Link to="/projects" className={`${linkStyle} bg-indigo-500 text-white hover:bg-indigo-400`}>View Projects <ArrowRight size={18} /></Link><Link to="/contact" className={`${linkStyle} border border-slate-700 hover:border-indigo-400`}>Get in Touch</Link></div></div>
        <div aria-hidden="true" className="relative overflow-hidden rounded-2xl border border-slate-800 bg-gradient-to-br from-indigo-500/20 via-slate-900 to-slate-900 p-8 sm:p-10"><Code2 size={40} className="mb-12 text-indigo-300" /><p className="font-mono text-sm text-slate-400">const developer = {'{'}</p><p className="my-5 pl-4 font-mono text-sm leading-8 text-indigo-200">name: 'Bassem Djeddi',<br />focus: 'Web interfaces',<br />mindset: 'Always learning'</p><p className="font-mono text-sm text-slate-400">{'}'}</p><div className="mt-12 border-t border-slate-700 pt-5 text-sm text-slate-400">Thoughtful interfaces. Practical solutions.</div></div>
      </section>
      <section className="border-t border-slate-800 py-20"><SectionTitle title="Skills & Technologies" subtitle="The tools I use to bring ideas to life." /><div className="flex flex-wrap gap-3">{skills.map((skill) => <SkillBadge key={skill} skill={skill} />)}</div></section>
      <section className="grid gap-8 border-t border-slate-800 py-20 md:grid-cols-[1fr_2fr]"><SectionTitle title="About Me" subtitle="Curiosity meets code." /><div className="space-y-5 leading-8 text-slate-400"><p>I enjoy the process of turning an idea into something people can use. My focus is on clear layouts, thoughtful interactions, and interfaces that feel comfortable on any screen.</p><p>I build with JavaScript and React, breaking interfaces into reusable components and paying attention to the details that make them work well together.</p><p>Learning is part of my everyday approach. Each project is an opportunity to explore a new tool, improve my problem-solving skills, and make the next experience better.</p></div></section>
      <section className="mb-20 rounded-xl border border-indigo-500/20 bg-indigo-500/10 p-8 sm:p-12"><h2 className="text-3xl font-bold text-white">Let's work together</h2><p className="mb-6 mt-3 text-slate-400">Have an idea or want to connect? I'd love to hear from you.</p><Link to="/contact" className={`${linkStyle} bg-indigo-500 text-white hover:bg-indigo-400`}>Get in Touch <ArrowRight size={18} /></Link></section>
    </div>
  )
}
