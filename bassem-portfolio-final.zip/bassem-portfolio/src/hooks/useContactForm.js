import { useEffect, useRef, useState } from 'react'
import { validateContactForm } from '../utils/validators'
const emptyValues = { name: '', email: '', subject: '', message: '' }
const emptyTouched = { name: false, email: false, subject: false, message: false }
export default function useContactForm() {
  const [values, setValues] = useState({ ...emptyValues })
  const [errors, setErrors] = useState({ ...emptyValues })
  const [touched, setTouched] = useState({ ...emptyTouched })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const timers = useRef([])
  const locked = useRef(false)
  useEffect(() => () => timers.current.forEach(clearTimeout), [])
  function reset() {
    timers.current.forEach(clearTimeout)
    timers.current = []
    locked.current = false
    setValues({ ...emptyValues })
    setErrors({ ...emptyValues })
    setTouched({ ...emptyTouched })
    setIsSubmitting(false)
    setIsSuccess(false)
  }
  function handleChange(event) {
    const { name, value } = event.target
    const next = { ...values, [name]: value }
    setValues(next)
    if (touched[name]) setErrors((previous) => ({ ...previous, [name]: validateContactForm(next)[name] }))
  }
  function handleBlur(event) {
    const { name } = event.target
    setTouched((previous) => ({ ...previous, [name]: true }))
    setErrors((previous) => ({ ...previous, [name]: validateContactForm(values)[name] }))
  }
  function handleSubmit(event) {
    event.preventDefault()
    if (locked.current) return
    const validation = validateContactForm(values)
    setErrors(validation)
    setTouched({ name: true, email: true, subject: true, message: true })
    if (Object.values(validation).some(Boolean)) return
    locked.current = true
    setIsSubmitting(true)
    timers.current.push(setTimeout(() => {
      setIsSubmitting(false)
      setIsSuccess(true)
      timers.current.push(setTimeout(reset, 4000))
    }, 1000))
  }
  return { values, errors, touched, isSubmitting, isSuccess, handleChange, handleBlur, handleSubmit, reset }
}
