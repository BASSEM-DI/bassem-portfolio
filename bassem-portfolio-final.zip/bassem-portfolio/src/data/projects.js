export const projects = [
  { id: 1, title: 'Task Manager App', description: 'Create, edit, and track daily tasks with local storage.', tech: ['React', 'Tailwind', 'LocalStorage'], link: '#', repo: '#' },
  { id: 2, title: 'Weather Dashboard', description: 'Fetch live weather data by city using a public API.', tech: ['React', 'API', 'Tailwind'], link: '#', repo: '#' },
  { id: 3, title: 'E-Commerce UI', description: 'A responsive product listing and cart interface.', tech: ['React', 'React Router', 'Tailwind'], link: '#', repo: '#' },
  { id: 4, title: 'Portfolio Website', description: 'This personal portfolio, built to share my work and connect with others.', tech: ['React', 'Vite', 'Tailwind'], link: '#', repo: '#' },
  { id: 5, title: 'Chat Interface', description: 'A minimal chat UI with simulated real-time messages.', tech: ['React', 'Hooks', 'Tailwind'], link: '#', repo: '#' },
  { id: 6, title: 'Movie Search', description: 'Search movies and view details from a public movie API.', tech: ['React', 'API', 'Tailwind'], link: '#', repo: '#' },
]
