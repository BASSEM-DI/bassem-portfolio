const normalize = (value) => String(value ?? '').trim()
export const isRequired = (value) => normalize(value) ? '' : 'This field is required.'
export const minLength = (value, n) => normalize(value).length >= n ? '' : `Please enter at least ${n} characters.`
export const isEmail = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalize(value)) ? '' : 'Please enter a valid email address.'
export function validateContactForm(fields) {
  return {
    name: isRequired(fields.name) || minLength(fields.name, 2),
    email: isRequired(fields.email) || isEmail(fields.email),
    subject: isRequired(fields.subject) || minLength(fields.subject, 3),
    message: isRequired(fields.message) || minLength(fields.message, 10),
  }
}
